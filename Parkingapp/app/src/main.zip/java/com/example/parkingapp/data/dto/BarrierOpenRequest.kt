package com.example.parkingapp.data.dto

data class BarrierOpenRequest(
    val slotId: Long
)