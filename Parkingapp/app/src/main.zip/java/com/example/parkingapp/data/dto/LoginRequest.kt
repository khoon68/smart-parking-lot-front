package com.example.parkingapp.data.dto

data class LoginRequest(
    val username: String,
    val password: String
)
