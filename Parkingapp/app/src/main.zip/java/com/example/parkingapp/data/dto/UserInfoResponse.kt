package com.example.parkingapp.data.dto

data class UserInfoResponse(
    val id: Int,
    val username: String,
    val role: String
)
