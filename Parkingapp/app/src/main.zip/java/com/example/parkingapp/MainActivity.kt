package com.example.parkingapp

import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.activity.viewModels
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.parkingapp.ui.theme.ParkingappTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.parkingapp.data.model.Reservation
import com.example.parkingapp.screens.auth.LoginScreen
import com.example.parkingapp.screens.auth.RegisterScreen
import com.example.parkingapp.screens.detail.ParkingDetailScreen
import com.example.parkingapp.screens.main.ParkingListScreen
import com.example.parkingapp.screens.mypage.MyPageScreen
import com.example.parkingapp.screens.parkingflow.ExitNoticeScreen
import com.example.parkingapp.screens.parkingflow.GateCloseScreen
import com.example.parkingapp.screens.parkingflow.GateOpenScreen
import com.example.parkingapp.screens.parkingflow.ParkingNoticeScreen
import com.example.parkingapp.screens.reservation.PaymentScreen
import com.example.parkingapp.screens.reservation.ReservationScreen
import com.example.parkingapp.screens.reservation.SlotSelectionScreen
import com.example.parkingapp.viewmodel.AuthViewModel
import com.example.parkingapp.viewmodel.ParkingListViewModel


class MainActivity : ComponentActivity() {

    private val viewModel by viewModels<ParkingListViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ParkingappTheme {
                val navController = rememberNavController()
                val context = LocalContext.current

                val viewModel: ParkingListViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return ParkingListViewModel(context.applicationContext) as T
                    }
                })
                val authViewModel: AuthViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return AuthViewModel(context.applicationContext) as T
                    }
                })
                NavHost(navController = navController, startDestination = "list") {
                    composable("reservation/{parkingId}") { backStackEntry ->
                        val parkingId = backStackEntry.arguments?.getString("parkingId")?.toIntOrNull()
                        val parkingList = viewModel.parkingList.collectAsState()
                        val selected = parkingList.value.find { it.id == parkingId }

                        if (selected != null) {
                            ReservationScreen(
                                parking = selected,
                                onBack = { navController.popBackStack() },
                                navController = navController,
                                viewModel = viewModel
                            )
                        }
                    }

                    // 로그인 회원가입
                    composable("login") {
                        LoginScreen(viewModel = authViewModel, navController = navController)
                    }
                    composable("register") {
                        RegisterScreen(viewModel = authViewModel, navController = navController)
                    }
                    // 마이페이지
                    composable("mypage") {
                        MyPageScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            navController = navController
                        )
                    }
                    // 목록
                    composable("list") {
                        ParkingListScreen(
                            viewModel = viewModel,
                            navController = navController
                        ) { selected ->
                            navController.navigate("detail/${selected.id}")  // ✅ 여기서 이동함
                        }
                    }
                    // 주차장 정보
                    composable("detail/{parkingId}") { backStackEntry ->   // ✅ detail 경로 추가!
                        val parkingId = backStackEntry.arguments?.getString("parkingId")?.toIntOrNull()
                        val parkingList by viewModel.parkingList.collectAsState()
                        val selected = remember(parkingList, parkingId) {
                            parkingList.find { it.id == parkingId }
                        }
                        if (selected != null) {
                            ParkingDetailScreen(
                                parking = selected,
                                onReserveClick = { navController.navigate("reservation/$it") },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                    // 결제화면
                    composable("payment") {
                        val reservation = navController.previousBackStackEntry
                            ?.savedStateHandle?.get<Reservation>("pendingReservation")
                        if (reservation != null) {
                            PaymentScreen(
                                reservation = reservation,
                                onConfirm = {
                                    viewModel.addReservation(reservation)
                                    navController.navigate("mypage") {
                                        popUpTo("list") { inclusive = false }
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                    // 주차칸 선택
                    composable("selectSlot/{parkingLotId}") { backStackEntry ->
                        val parkingLotId = backStackEntry.arguments?.getString("parkingLotId")?.toLongOrNull()
                        val timeSlots = navController.previousBackStackEntry?.savedStateHandle?.get<List<String>>("selectedTimeSlots")
                        if (parkingLotId != null && timeSlots != null) {
                            SlotSelectionScreen(
                                parkingLotId = parkingLotId,
                                date = "2025-06-01", // ⚠️ 테스트용 고정값
                                timeSlots = timeSlots,
                                navController = navController,
                                viewModel = viewModel,
                                onSlotSelected = { selectedSlotId ->
                                    // 테스트용 예약 객체 생성
                                    val fakeReservation = Reservation(
                                        id = viewModel.getNextReservationId(),
                                        parking = viewModel.parkingList.value.first { it.id == parkingLotId.toInt() },
                                        timeSlots = timeSlots,
                                        totalPrice = timeSlots.size * 2000,
                                        isOngoing = false,
                                        slotId = selectedSlotId!!
                                    )
                                    navController.previousBackStackEntry?.savedStateHandle?.set("pendingReservation", fakeReservation)
                                    navController.navigate("payment")
                                }
                            )
                        }
                    }
                    // 차단기 제어 화면
                    composable("start/{reservationId}/{slotId}") { backStackEntry ->
                        val reservationId = backStackEntry.arguments?.getString("reservationId")?.toIntOrNull()
                        val slotId = backStackEntry.arguments?.getString("slotId")?.toLongOrNull()

                        if (reservationId != null && slotId != null) {
                            GateOpenScreen(
                                reservationId = reservationId,
                                slotId = slotId,
                                navController = navController,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                    // 주차 시 주의사항
                    composable("notice/{reservationId}/{slotId}") { backStackEntry ->
                        val id = backStackEntry.arguments?.getString("reservationId")?.toIntOrNull()
                        val slotId = backStackEntry.arguments?.getString("slotId")?.toLongOrNull()

                        if (id != null && slotId != null) {
                            ParkingNoticeScreen(
                                onProceed = {
                                    navController.navigate("start/$id/$slotId") // ✅ slotId 포함해서 전달
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }

                    // 출차 시 주의사항
                    composable("exitNotice/{reservationId}") { backStackEntry ->
                        val reservationId = backStackEntry.arguments?.getString("reservationId")?.toIntOrNull()
                        if (reservationId != null) {
                            ExitNoticeScreen(
                                onProceed = {
                                    navController.navigate("gateClose/$id")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                    // 출차
                    composable("gateClose/{reservationId}/{slotId}") { backStackEntry ->
                        val reservationId = backStackEntry.arguments?.getString("reservationId")?.toIntOrNull()
                        val slotId = backStackEntry.arguments?.getString("slotId")?.toLongOrNull()

                        if (reservationId != null && slotId != null) {
                            GateCloseScreen(
                                reservationId = reservationId,
                                slotId = slotId, // ✅ slotId 전달
                                navController = navController,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}




