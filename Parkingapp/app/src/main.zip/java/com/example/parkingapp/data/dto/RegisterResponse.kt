package com.example.parkingapp.data.dto

data class RegisterResponse(
    val message: String,
    val userId: Int
)
