package com.example.parkingapp.screens.reservation

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.parkingapp.components.TopBar
import com.example.parkingapp.data.api.RetrofitInstance
import com.example.parkingapp.data.dto.ReservationRequest
import com.example.parkingapp.data.model.Reservation
import com.example.parkingapp.ui.theme.formatContinuousTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PaymentScreen(
    reservation: Reservation,
    navController: NavController,
    viewModel: com.example.parkingapp.viewmodel.ParkingListViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val api = remember { RetrofitInstance.create(context) }

    Scaffold(
        topBar = {
            TopBar(title = "결제", showBack = true, onBackClick = onBack)
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("주차장: ${reservation.parkingLotName}", style = MaterialTheme.typography.titleMedium)
            Text("예약 시간: ${reservation.startTime} ~ ${reservation.endTime}")
            Text("총 요금: ${reservation.totalPrice}원")

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val request = ReservationRequest(
                                slotId = reservation.slotNumber.toLong(),
                                timeSlots = listOf(reservation.startTime, reservation.endTime)
                            )
                            val response = api.createReservation(request)
                            if (response.isSuccessful) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "예약이 완료되었습니다.", Toast.LENGTH_SHORT).show()
                                    navController.navigate("mypage") {
                                        popUpTo("list") { inclusive = false }
                                    }
                                }
                            } else {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "예약 실패: ${response.code()}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "오류: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("결제하기")
            }
        }
    }
}

